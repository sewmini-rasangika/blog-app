
<?php $__env->startSection('code', '404'); ?>
<?php $__env->startSection('heading', 'Not found page 🧭'); ?>
<?php $__env->startSection('message', 'The page you are looking for has been deleted and wrong address. Search, otherwise go to home.'); ?>
<?php $__env->startSection('extra'); ?>
  <form action="<?php echo e(route('search')); ?>" method="GET" class="err-search">
    <i class="bi bi-search"></i>
    <input type="search" name="q" class="form-control" placeholder="Search posts...">
  </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('errors.base', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\blog-app\resources\views/errors/404.blade.php ENDPATH**/ ?>