<article class="post-card card h-100">
  <div class="post-thumb">
    <a href="<?php echo e(route('post.show', $post->slug)); ?>" class="d-block h-100" aria-label="<?php echo e($post->title); ?>">
      <?php if($post->featured): ?>
        <img src="<?php echo e(asset('storage/' . $post->featured)); ?>" alt="<?php echo e($post->title); ?>" loading="lazy">
      <?php else: ?>
        <div class="thumb-placeholder"><i class="bi bi-journal-richtext"></i></div>
      <?php endif; ?>
    </a>
    <a href="<?php echo e(route('category.show', $post->category->slug)); ?>" class="cat-pill"><?php echo e($post->category->name); ?></a>
  </div>

  <div class="card-body d-flex flex-column">
    <h5 class="post-title">
      <a href="<?php echo e(route('post.show', $post->slug)); ?>"><?php echo e($post->title); ?></a>
    </h5>
    <p class="post-excerpt"><?php echo e($post->excerpt); ?></p>

    <div class="post-meta mt-auto">
      <a href="<?php echo e(route('author.show', $post->user)); ?>" class="author">
        <span class="avatar-sm"><?php echo e(mb_strtoupper(mb_substr($post->user->name, 0, 1))); ?></span>
        <?php echo e($post->user->name); ?>

      </a>
      <span>
        <?php echo e($post->created_at->format('M d, Y')); ?>

        · <i class="bi bi-clock"></i> <?php echo e($post->reading_time); ?> min
      </span>
    </div>
  </div>
</article><?php /**PATH C:\xampp\htdocs\laravel\blog-app\resources\views/frontend/_card.blade.php ENDPATH**/ ?>