<?php
  $avatar = $comment->user?->profile?->avatar;
  $role = $comment->user?->isAdmin() ? 'Admin' : ($comment->user_id && $comment->user_id === $post->user_id ? 'Author' : null);
?>

<div class="comment <?php echo e($isReply ? 'is-reply' : ''); ?>" id="comment-<?php echo e($comment->id); ?>">
  <span class="c-avatar">
    <?php if($avatar): ?>
      <img src="<?php echo e(asset('storage/' . $avatar)); ?>" alt="" loading="lazy">
    <?php else: ?>
      <?php echo e(mb_strtoupper(mb_substr($comment->name, 0, 1))); ?>

    <?php endif; ?>
  </span>

  <div class="c-body">
    <div class="c-head">
      <strong><?php echo e($comment->name); ?></strong>
      <?php if($role): ?> <span class="c-badge"><?php echo e($role); ?></span> <?php endif; ?>
      <span class="c-time"><?php echo e($comment->created_at->diffForHumans()); ?></span>
    </div>

    <p class="c-text"><?php echo nl2br(e($comment->body)); ?></p>

    <?php if (! ($isReply)): ?>
      <?php if($post->status === 'approved'): ?>
        <button type="button" class="c-reply-btn" data-reply="<?php echo e($comment->id); ?>">
          <i class="bi bi-reply-fill"></i> Reply
        </button>

        <div class="reply-box <?php echo e((string) old('parent_id') === (string) $comment->id ? '' : 'd-none'); ?>" id="reply-box-<?php echo e($comment->id); ?>">
          <?php echo $__env->make('frontend._comment_form', ['post' => $post, 'parentId' => $comment->id], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        </div>
      <?php endif; ?>

      <?php $__currentLoopData = $comment->replies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reply): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php echo $__env->make('frontend._comment', ['comment' => $reply, 'post' => $post, 'isReply' => true], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
  </div>
</div>
<?php
  $avatar = $comment->user?->profile?->avatar;
  $role = $comment->user?->isAdmin() ? 'Admin' : ($comment->user_id && $comment->user_id === $post->user_id ? 'Author' : null);
?>

<div class="comment <?php echo e($isReply ? 'is-reply' : ''); ?>" id="comment-<?php echo e($comment->id); ?>">
  <?php if($comment->replies->count() > 0): ?>
    <div class="ml-8 mt-4">
        <?php $__currentLoopData = $comment->replies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reply): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php echo $__env->make('frontend._comment', ['comment' => $reply, 'post' => $post, 'isReply' => true], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php endif; ?>
</div>
<?php /**PATH C:\xampp\htdocs\laravel\blog-app\resources\views/frontend/_comment.blade.php ENDPATH**/ ?>