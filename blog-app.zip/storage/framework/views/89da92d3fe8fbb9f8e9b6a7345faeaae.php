
<?php $__env->startSection('title', 'My Blog'); ?>

<?php $__env->startSection('content'); ?>
<?php if($posts->isEmpty()): ?>
  <div class="empty-state">
    <i class="bi bi-journal-x"></i>
    <h5>  No posts</h5>
    <p class="text-muted">Be the first person to write the first post!</p>
    <?php if(auth()->guard()->guest()): ?>
      <a href="<?php echo e(route('register')); ?>" class="btn btn-primary">Register</a>
    <?php else: ?>
      <a href="<?php echo e(route('posts.create')); ?>" class="btn btn-primary">+ New Post</a>
    <?php endif; ?>
  </div>
<?php else: ?>
  <?php
    $hero = $posts->onFirstPage() ? $posts->first() : null;
    $rest = $hero ? $posts->slice(1) : $posts;
  ?>


  <?php if($hero): ?>
    <a href="<?php echo e(route('post.show', $hero->slug)); ?>" class="hero-feature">
      <div class="hero-bg <?php echo e($hero->featured ? '' : 'no-img'); ?>"
           <?php if($hero->featured): ?> style="background-image:url('<?php echo e(asset('storage/' . $hero->featured)); ?>')" <?php endif; ?>></div>

      <div class="hero-body">
        <span class="hero-chip"><i class="bi bi-stars"></i> Latest · <?php echo e($hero->category->name); ?></span>
        <h2 class="hero-title"><?php echo e($hero->title); ?></h2>
        <p class="hero-excerpt d-none d-md-block"><?php echo e($hero->excerpt); ?></p>

        <div class="hero-meta">
          <span class="d-inline-flex align-items-center gap-2">
            <span class="avatar-sm on-dark"><?php echo e(mb_strtoupper(mb_substr($hero->user->name, 0, 1))); ?></span>
            <?php echo e($hero->user->name); ?>

          </span>
          <span><i class="bi bi-calendar3"></i> <?php echo e($hero->created_at->format('M d, Y')); ?></span>
          <span><i class="bi bi-clock"></i> <?php echo e($hero->reading_time); ?> min read</span>
          <span class="hero-cta">Read more <i class="bi bi-arrow-right"></i></span>
        </div>
      </div>
    </a>
  <?php endif; ?>


  <?php if($rest->isNotEmpty()): ?>
    <h2 class="section-title"><?php echo e($hero ? 'Latest Posts' : 'More Posts'); ?></h2>

    <div class="row g-4">
      <?php $__currentLoopData = $rest; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-6"><?php echo $__env->make('frontend._card', ['post' => $post], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?></div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
  <?php endif; ?>

  <div class="mt-4 d-flex justify-content-center">
    <?php echo e($posts->links('pagination::bootstrap-5')); ?>

  </div>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\blog-app\resources\views/frontend/index.blade.php ENDPATH**/ ?>