<?php
  $parentId = $parentId ?? null;
  $mine = (string) old('parent_id') === (string) $parentId;
  $err = fn ($field) => $mine && $errors->has($field);
?>

<form method="POST" action="<?php echo e(route('comments.store', $post->slug)); ?>"
      class="<?php echo e($parentId ? 'reply-form' : 'card comment-form shadow-sm'); ?>">
  <?php echo csrf_field(); ?>
  <?php if($parentId): ?>
    <input type="hidden" name="parent_id" value="<?php echo e($parentId); ?>">
  <?php endif; ?>


  <input type="text" name="website" class="d-none" tabindex="-1" autocomplete="off" aria-hidden="true">

  <?php if(auth()->guard()->guest()): ?>
    <div class="row g-2 mb-2">
      <div class="col-md-6">
        <input type="text" name="name" value="<?php echo e($mine ? old('name') : ''); ?>" maxlength="60" required
               class="form-control <?php if($err('name')): ?> is-invalid <?php endif; ?>" placeholder="your name *">
        <?php if($err('name')): ?> <div class="invalid-feedback"><?php echo e($errors->first('name')); ?></div> <?php endif; ?>
      </div>
      <div class="col-md-6">
        <input type="email" name="email" value="<?php echo e($mine ? old('email') : ''); ?>" maxlength="120" required
               class="form-control <?php if($err('email')): ?> is-invalid <?php endif; ?>" placeholder="Email * (not show)">
        <?php if($err('email')): ?> <div class="invalid-feedback"><?php echo e($errors->first('email')); ?></div> <?php endif; ?>
      </div>
    </div>
  <?php else: ?>
    <div class="small text-muted mb-2">
      <i class="bi bi-person-check-fill text-success"></i>
      <strong><?php echo e(auth()->user()->name); ?></strong> comment
    </div>
  <?php endif; ?>

  <textarea name="body" rows="<?php echo e($parentId ? 3 : 4); ?>" maxlength="1500" required
            class="form-control <?php if($err('body')): ?> is-invalid <?php endif; ?>"
            placeholder="<?php echo e($parentId ? 'type reply...' : 'write your idea...'); ?>"><?php echo e($mine ? old('body') : ''); ?></textarea>
  <?php if($err('body')): ?> <div class="invalid-feedback d-block"><?php echo e($errors->first('body')); ?></div> <?php endif; ?>

  <div class="d-flex flex-wrap justify-content-between align-items-center gap-2 mt-2">
    <small class="text-muted">show approved admin</small>
    <button type="submit" class="btn btn-primary btn-sm px-3">
      <i class="bi bi-send-fill me-1"></i> <?php echo e($parentId ? 'Reply' : 'Post comment'); ?>

    </button>
  </div>
</form><?php /**PATH C:\xampp\htdocs\laravel\blog-app\resources\views/frontend/_comment_form.blade.php ENDPATH**/ ?>