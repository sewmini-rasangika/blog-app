
<?php $__env->startSection('title', 'My Dashboard'); ?>

<?php $__env->startSection('content'); ?>
<div class="welcome mb-4">
  <div>
    <h2>Welcome, <?php echo e(auth()->user()->name); ?> 👋</h2>
    <p>Posts ypu submit will apear on the site once approved by the admin.</p>
  </div>
  <a href="<?php echo e(route('posts.create')); ?>" class="btn btn-light fw-semibold"><i class="bi bi-plus-lg me-1"></i> New Post</a>
</div>

<div class="row g-3 mb-4">
  <div class="col-6 col-xl-3">
    <a href="<?php echo e(route('posts.index', ['status' => 'all'])); ?>" class="stat-card">
      <span class="stat-icon violet"><i class="bi bi-journal-text"></i></span>
      <div><div class="stat-num"><?php echo e($counts->sum()); ?></div><div class="stat-label">My posts</div></div>
    </a>
  </div>
  <div class="col-6 col-xl-3">
    <a href="<?php echo e(route('posts.index', ['status' => 'pending'])); ?>" class="stat-card">
      <span class="stat-icon amber"><i class="bi bi-hourglass-split"></i></span>
      <div><div class="stat-num"><?php echo e($counts['pending'] ?? 0); ?></div><div class="stat-label">Pending</div></div>
    </a>
  </div>
  <div class="col-6 col-xl-3">
    <a href="<?php echo e(route('posts.index', ['status' => 'approved'])); ?>" class="stat-card">
      <span class="stat-icon green"><i class="bi bi-patch-check-fill"></i></span>
      <div><div class="stat-num"><?php echo e($counts['approved'] ?? 0); ?></div><div class="stat-label">Published</div></div>
    </a>
  </div>
  <div class="col-6 col-xl-3">
    <a href="<?php echo e(route('posts.index', ['status' => 'rejected'])); ?>" class="stat-card">
      <span class="stat-icon rose"><i class="bi bi-x-octagon-fill"></i></span>
      <div><div class="stat-num"><?php echo e($counts['rejected'] ?? 0); ?></div><div class="stat-label">Rejected</div></div>
    </a>
  </div>
</div>

<div class="card shadow-sm">
  <div class="queue-head">
    <h5>🕒 My recent posts</h5>
    <a href="<?php echo e(route('posts.index')); ?>" class="small fw-semibold">View all →</a>
  </div>

  <?php $__empty_1 = true; $__currentLoopData = $recent; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <?php $badge = ['pending' => 'warning', 'approved' => 'success', 'rejected' => 'danger'][$post->status]; ?>
    <div class="queue-item">
      <div>
        <a href="<?php echo e(route('posts.edit', $post)); ?>" class="q-title"><?php echo e($post->title); ?></a>
        <div class="q-sub"><?php echo e($post->category->name); ?> · <?php echo e($post->created_at->diffForHumans()); ?></div>
      </div>
      <div class="q-actions">
        <span class="badge bg-<?php echo e($badge); ?>"><?php echo e(ucfirst($post->status)); ?></span>
      </div>
    </div>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    <div class="queue-empty">
      <i class="bi bi-pencil-square"></i>
      No posts. Write the first post!
      <div class="mt-3"><a href="<?php echo e(route('posts.create')); ?>" class="btn btn-primary">+ New Post</a></div>
    </div>
  <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\blog-app\resources\views/admin/dashboard-author.blade.php ENDPATH**/ ?>