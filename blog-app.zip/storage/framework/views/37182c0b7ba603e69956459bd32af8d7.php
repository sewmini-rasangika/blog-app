
<?php $__env->startSection('title', $title); ?>

<?php $__env->startSection('seo'); ?>
  <?php echo $__env->make('partials.seo', [
    'seoTitle'   => $title,
    'seoNoindex' => request()->routeIs('search'),
  ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="page-head">
  <h3><?php echo e($title); ?></h3>
  <p><?php echo e($posts->total()); ?> <?php echo e(\Illuminate\Support\Str::plural('post', $posts->total())); ?></p>
</div>

<?php if($posts->isEmpty()): ?>
  <div class="empty-state">
    <i class="bi bi-search"></i>
    <h5>No posts found</h5>
    <p class="text-muted mb-3">Try searching with another kerword, or go to back to home.</p>
    <a href="<?php echo e(route('home')); ?>" class="btn btn-primary">← Home</a>
  </div>
<?php else: ?>
  <div class="row g-4">
    <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="col-md-6"><?php echo $__env->make('frontend._card', ['post' => $post], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?></div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>

  <div class="mt-4 d-flex justify-content-center">
    <?php echo e($posts->links('pagination::bootstrap-5')); ?>

  </div>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\blog-app\resources\views/frontend/list.blade.php ENDPATH**/ ?>