<div class="reactions" id="reactions"
     data-url="<?php echo e(route('post.react', $post->slug)); ?>"
     data-token="<?php echo e(csrf_token()); ?>">
  <?php $__currentLoopData = \App\Models\Reaction::TYPES; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type => $emoji): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <button type="button" class="react-btn <?php echo e($myReaction === $type ? 'active' : ''); ?>"
            data-type="<?php echo e($type); ?>" title="<?php echo e(ucfirst($type)); ?>">
      <span class="emoji"><?php echo e($emoji); ?></span>
      <span class="count"><?php echo e($reactionCounts[$type] ?? 0); ?></span>
    </button>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>

<?php $__env->startPush('scripts'); ?>
<script>
(function () {
  const box = document.getElementById('reactions');
  if (!box) return;

  box.addEventListener('click', async function (e) {
    const btn = e.target.closest('.react-btn');
    if (!btn || box.dataset.busy) return;
    box.dataset.busy = '1';

    try {
      const res = await fetch(box.dataset.url, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Accept': 'application/json',
          'X-CSRF-TOKEN': box.dataset.token
        },
        body: JSON.stringify({ type: btn.dataset.type })
      });
      if (!res.ok) throw new Error(res.status);
      const data = await res.json();

      box.querySelectorAll('.react-btn').forEach(function (b) {
        b.classList.toggle('active', b.dataset.type === data.mine);
        b.querySelector('.count').textContent = data.counts[b.dataset.type] ?? 0;
      });
    } catch (err) {
      alert('Reaction eka save una nae. Poddak inna ayeth try karanna.');
    } finally {
      delete box.dataset.busy;
    }
  });
})();
</script>
<?php $__env->stopPush(); ?><?php /**PATH C:\xampp\htdocs\laravel\blog-app\resources\views/frontend/_reactions.blade.php ENDPATH**/ ?>