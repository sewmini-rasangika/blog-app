
<?php $__env->startSection('title', 'Posts'); ?>

<?php $__env->startSection('content'); ?>
<?php
  $seeAll = auth()->user()->can('posts.view_all');
  $canApprove = auth()->user()->can('posts.approve');
  $badge = ['pending' => 'warning', 'approved' => 'success', 'rejected' => 'danger'];
  $tabs = ['all' => 'All', 'pending' => 'Pending', 'approved' => 'Approved', 'rejected' => 'Rejected'];
?>

<div class="d-flex justify-content-between align-items-center mb-3">
  <h3 class="mb-0"><?php echo e($seeAll ? 'All Posts' : 'My Posts'); ?></h3>
  <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('posts.create')): ?>
    <a href="<?php echo e(route('posts.create')); ?>" class="btn btn-primary">+ New Post</a>
  <?php endif; ?>
</div>

<?php if($authorFilter): ?>
  <div class="alert alert-secondary py-2">
    Author: <strong><?php echo e($authorFilter->name); ?></strong>
    <a href="<?php echo e(route('posts.index', request()->except(['author', 'page']))); ?>" class="ms-2">✕ clear</a>
  </div>
<?php endif; ?>


<ul class="nav nav-tabs mb-3">
  <?php $__currentLoopData = $tabs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <li class="nav-item">
      <a class="nav-link <?php echo e($status === $key ? 'active' : ''); ?>"
         href="<?php echo e(route('posts.index', array_merge(request()->except(['page', 'status']), ['status' => $key]))); ?>">
        <?php echo e($label); ?>

        <span class="badge bg-<?php echo e($key === 'pending' ? 'warning' : 'secondary'); ?>">
          <?php echo e($key === 'all' ? $counts->sum() : ($counts[$key] ?? 0)); ?>

        </span>
      </a>
    </li>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>


<form method="GET" class="row g-2 mb-3">
  <input type="hidden" name="status" value="<?php echo e($status); ?>">
  <?php if($authorFilter): ?><input type="hidden" name="author" value="<?php echo e($authorFilter->id); ?>"><?php endif; ?>
  <div class="col-md-5">
    <input type="text" name="q" value="<?php echo e(request('q')); ?>" class="form-control" placeholder="Search by title...">
  </div>
  <div class="col-md-4">
    <select name="category" class="form-select">
      <option value="">All categories</option>
      <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($c->id); ?>" <?php if(request('category') == $c->id): echo 'selected'; endif; ?>><?php echo e($c->name); ?></option>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
  </div>
  <div class="col-md-3">
    <button class="btn btn-dark">Filter</button>
    <a href="<?php echo e(route('posts.index', ['status' => $status])); ?>" class="btn btn-outline-secondary">Reset</a>
  </div>
</form>

<div class="card shadow-sm">
  <div class="table-responsive">
    <table class="table table-hover mb-0 align-middle">
      <thead>
        <tr>
          <th>Image</th><th>Title</th><th>Category</th>
          <?php if($seeAll): ?><th>Author</th><?php endif; ?>
          <th>Status</th><th>Date</th><th class="text-end">Actions</th>
        </tr>
      </thead>
      <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
          <tr>
            <td>
              <?php if($post->featured): ?>
                <img src="<?php echo e(asset('storage/' . $post->featured)); ?>" width="60" class="rounded">
              <?php else: ?> <span class="text-muted">-</span> <?php endif; ?>
            </td>
            <td><a href="<?php echo e(route('post.show', $post->slug)); ?>" target="_blank" class="text-decoration-none"><?php echo e($post->title); ?></a></td>
            <td><span class="badge bg-info text-dark"><?php echo e($post->category->name); ?></span></td>
            <?php if($seeAll): ?>
              <td><a href="<?php echo e(route('posts.index', ['author' => $post->user_id, 'status' => 'all'])); ?>" class="text-decoration-none"><?php echo e($post->user->name); ?></a></td>
            <?php endif; ?>
            <td><span class="badge bg-<?php echo e($badge[$post->status]); ?>"><?php echo e(ucfirst($post->status)); ?></span></td>
            <td class="small text-muted"><?php echo e($post->created_at->format('M d, Y')); ?></td>
            <td class="text-end text-nowrap">
              <?php if($canApprove && $post->status !== 'approved'): ?>
                <form method="POST" action="<?php echo e(route('posts.approve', $post)); ?>" class="d-inline">
                  <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>
                  <button class="btn btn-sm btn-success">Approve</button>
                </form>
              <?php endif; ?>
              <?php if($canApprove && $post->status !== 'rejected'): ?>
                <form method="POST" action="<?php echo e(route('posts.reject', $post)); ?>" class="d-inline">
                  <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>
                  <button class="btn btn-sm btn-outline-danger">Reject</button>
                </form>
              <?php endif; ?>
              <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update', $post)): ?>
                <a href="<?php echo e(route('posts.edit', $post)); ?>" class="btn btn-sm btn-warning">Edit</a>
              <?php endif; ?>
              <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete', $post)): ?>
                <button type="button" class="btn btn-sm btn-danger"
                  data-bs-toggle="modal" data-bs-target="#deleteModal"
                  data-action="<?php echo e(route('posts.destroy', $post)); ?>"
                  data-name="<?php echo e($post->title); ?>">Trash</button>
              <?php endif; ?>
            </td>
          </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
          <tr><td colspan="7" class="text-center text-muted py-4">No posts.</td></tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>

<div class="mt-3"><?php echo e($posts->links('pagination::bootstrap-5')); ?></div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\blog-app\resources\views/admin/posts/index.blade.php ENDPATH**/ ?>