
<?php $__env->startSection('title', 'Edit Post'); ?>

<?php $__env->startSection('content'); ?>
<h3 class="mb-3">Edit Post</h3>
<form method="POST" action="<?php echo e(route('posts.update', $post)); ?>" enctype="multipart/form-data" class="card card-body shadow-sm">
  <?php echo csrf_field(); ?>
  <?php echo method_field('PUT'); ?>
  <?php echo $__env->make('admin.posts._form', ['button' => 'Update'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\blog-app\resources\views/admin/posts/edit.blade.php ENDPATH**/ ?>