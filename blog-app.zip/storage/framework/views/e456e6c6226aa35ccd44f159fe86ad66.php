

<?php $__env->startSection('title', $post->seo_title); ?>

<?php $__env->startSection('seo'); ?>
  <?php echo $__env->make('partials.seo', [
    'seoTitle'       => $post->seo_title,
    'seoDescription' => $post->seo_description,
    'seoKeywords'    => $post->seo_keywords,
    'seoImage'       => $post->seo_image,
    'seoType'        => 'article',
    'seoUrl'         => route('post.show', $post->slug),
    'seoNoindex'     => $post->status !== 'approved',    // pending/rejected preview එක Google ට index කරන්න එපා
    'seoJsonLd'      => $post->seoJsonLd(),
  ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="read-progress" id="readBar"></div>

<?php if($post->status !== 'approved'): ?>
  <div class="alert alert-warning">
    <i class="bi bi-eye-fill me-1"></i>
    This <strong><?php echo e(ucfirst($post->status)); ?></strong> is a post. Only visible to you(author/admin).
  </div>
<?php endif; ?>


<nav class="crumbs" aria-label="breadcrumb">
  <a href="<?php echo e(route('home')); ?>"><i class="bi bi-house-door-fill"></i> Home</a>
  <i class="bi bi-chevron-right"></i>
  <a href="<?php echo e(route('category.show', $post->category->slug)); ?>"><?php echo e($post->category->name); ?></a>
  <i class="bi bi-chevron-right"></i>
  <span class="current"><?php echo e($post->title); ?></span>
</nav>


<article class="card article shadow-sm mb-4">
  <a href="<?php echo e(route('category.show', $post->category->slug)); ?>" class="article-cat align-self-start"><?php echo e($post->category->name); ?></a>
  <h1 class="article-title"><?php echo e($post->title); ?></h1>

  <div class="article-meta">
    <a href="<?php echo e(route('author.show', $post->user)); ?>" class="by">
      <span class="avatar-sm">
        <?php if($post->user->profile?->avatar): ?>
          <img src="<?php echo e(asset('storage/' . $post->user->profile->avatar)); ?>" alt="">
        <?php else: ?>
          <?php echo e(mb_strtoupper(mb_substr($post->user->name, 0, 1))); ?>

        <?php endif; ?>
      </span>
      <?php echo e($post->user->name); ?>

    </a>
    <span><i class="bi bi-calendar3"></i> <?php echo e($post->created_at->format('M d, Y')); ?></span>
    <span><i class="bi bi-clock"></i> <?php echo e($post->reading_time); ?> min read</span>
    <span><i class="bi bi-eye"></i> <?php echo e(number_format($post->views)); ?> views</span>
  </div>

  <?php if($post->featured): ?>
    <figure class="post-cover">
      <img src="<?php echo e(asset('storage/' . $post->featured)); ?>" alt="<?php echo e($post->title); ?>">
    </figure>
  <?php endif; ?>

 <div class="post-content"><?php echo $post->body_html; ?></div>

  <?php if($post->tags->isNotEmpty()): ?>
    <div class="tag-row">
      <i class="bi bi-tags-fill text-muted"></i>
      <?php $__currentLoopData = $post->tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <a href="<?php echo e(route('tag.show', $tag->slug)); ?>" class="tag-chip">#<?php echo e($tag->name); ?></a>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
  <?php endif; ?>
    <?php if($post->tags->isNotEmpty()): ?>

  <?php endif; ?>

  
  <?php if($post->status === 'approved'): ?>
    <?php echo $__env->make('frontend._reactions', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
  <?php endif; ?>

    <?php
    $shareUrl = urlencode(url()->current());
    $shareTitle = urlencode($post->title);
  ?>
  <div class="share-bar">
    <strong><i class="bi bi-share-fill me-1"></i>Share</strong>
    <a href="https://www.facebook.com/sharer/sharer.php?u=<?php echo e($shareUrl); ?>" target="_blank" rel="noopener" class="btn-share fb"><i class="bi bi-facebook"></i> Facebook</a>
    <a href="https://twitter.com/intent/tweet?url=<?php echo e($shareUrl); ?>&text=<?php echo e($shareTitle); ?>" target="_blank" rel="noopener" class="btn-share x"><i class="bi bi-twitter-x"></i> X</a>
    <a href="https://wa.me/?text=<?php echo e($shareTitle); ?>%20<?php echo e($shareUrl); ?>" target="_blank" rel="noopener" class="btn-share wa"><i class="bi bi-whatsapp"></i> WhatsApp</a>
    <button type="button" class="btn-share copy" id="copyLink"><i class="bi bi-link-45deg"></i> Copy link</button>
  </div>
</article>


<div class="card author-box shadow-sm mb-4">
  <div class="author-avatar">
    <?php if($post->user->profile?->avatar): ?>
      <img src="<?php echo e(asset('storage/' . $post->user->profile->avatar)); ?>" alt="<?php echo e($post->user->name); ?>">
    <?php else: ?>
      <?php echo e(mb_strtoupper(mb_substr($post->user->name, 0, 1))); ?>

    <?php endif; ?>
  </div>
  <div>
    <small class="text-muted text-uppercase fw-semibold" style="letter-spacing:.8px">Written by</small>
    <h6><?php echo e($post->user->name); ?></h6>
    <p class="about"><?php echo e($post->user->profile?->about ?: 'this author no detais.'); ?></p>
    <a href="<?php echo e(route('author.show', $post->user)); ?>" class="btn btn-primary btn-sm">More posts</a>
    <?php if($post->user->profile?->facebook): ?>
      <a href="<?php echo e($post->user->profile->facebook); ?>" target="_blank" rel="noopener" class="btn btn-outline-dark btn-sm">
        <i class="bi bi-facebook"></i>
      </a>
    <?php endif; ?>
  </div>
</div>


<?php if($prev || $next): ?>
  <div class="row g-3 mb-4">
    <div class="col-sm-6">
      <?php if($prev): ?>
        <a href="<?php echo e(route('post.show', $prev->slug)); ?>" class="nav-post">
          <small><i class="bi bi-arrow-left"></i> Previous</small>
          <span><?php echo e(\Illuminate\Support\Str::limit($prev->title, 60)); ?></span>
        </a>
      <?php endif; ?>
      
    </div>
    <div class="col-sm-6">
      <?php if($next): ?>
        <a href="<?php echo e(route('post.show', $next->slug)); ?>" class="nav-post next">
          <small>Next <i class="bi bi-arrow-right"></i></small>
          <span><?php echo e(\Illuminate\Support\Str::limit($next->title, 60)); ?></span>
        </a>
      <?php endif; ?>
    </div>
  </div>
<?php endif; ?>

<?php echo $__env->make('frontend._comments', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>



<?php if($related->isNotEmpty()): ?>
  <h2 class="section-title mt-5">You may also like</h2>
  <div class="row g-4">
    <?php $__currentLoopData = $related; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="col-md-6 col-xl-4"><?php echo $__env->make('frontend._card', ['post' => $rel], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?></div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
  
  const bar = document.getElementById('readBar');
  const updateBar = () => {
    const h = document.documentElement;
    const max = h.scrollHeight - h.clientHeight;
    bar.style.width = (max > 0 ? (h.scrollTop / max) * 100 : 0) + '%';
  };
  window.addEventListener('scroll', updateBar, { passive: true });
  updateBar();

  document.getElementById('copyLink').addEventListener('click', function () {
    navigator.clipboard.writeText(window.location.href).then(() => {
      const old = this.innerHTML;
      this.innerHTML = '<i class="bi bi-check2"></i> Copied!';
      setTimeout(() => this.innerHTML = old, 2000);
    });
  });
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.frontend', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\blog-app\resources\views/frontend/show.blade.php ENDPATH**/ ?>