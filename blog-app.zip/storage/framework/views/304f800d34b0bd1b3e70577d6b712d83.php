
<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content'); ?>
<?php $pending = $counts['pending'] ?? 0; ?>

<div class="welcome mb-4">
  <div>
    <h2>Hi, <?php echo e(auth()->user()->name); ?> 👋</h2>
    <p>
      <?php if($pending > 0): ?>
        Approve posts <strong><?php echo e($pending); ?></strong>waiting.
      <?php else: ?>
        All are approved. 🎉
      <?php endif; ?>
    </p>
  </div>
  <a href="<?php echo e(route('posts.index', ['status' => 'pending'])); ?>" class="btn btn-light fw-semibold">
    Review queue <i class="bi bi-arrow-right ms-1"></i>
  </a>
</div>

<div class="row g-3 mb-3">
  <div class="col-6 col-xl-3">
    <a href="<?php echo e(route('posts.index', ['status' => 'pending'])); ?>" class="stat-card">
      <span class="stat-icon amber"><i class="bi bi-hourglass-split"></i></span>
      <div><div class="stat-num"><?php echo e($pending); ?></div><div class="stat-label">Pending approval</div></div>
    </a>
  </div>
  <div class="col-6 col-xl-3">
    <a href="<?php echo e(route('posts.index', ['status' => 'approved'])); ?>" class="stat-card">
      <span class="stat-icon green"><i class="bi bi-patch-check-fill"></i></span>
      <div><div class="stat-num"><?php echo e($counts['approved'] ?? 0); ?></div><div class="stat-label">Published</div></div>
    </a>
  </div>
  <div class="col-6 col-xl-3">
    <a href="<?php echo e(route('posts.index', ['status' => 'rejected'])); ?>" class="stat-card">
      <span class="stat-icon rose"><i class="bi bi-x-octagon-fill"></i></span>
      <div><div class="stat-num"><?php echo e($counts['rejected'] ?? 0); ?></div><div class="stat-label">Rejected</div></div>
    </a>
  </div>
  <div class="col-6 col-xl-3">
    <a href="<?php echo e(route('users.index')); ?>" class="stat-card">
      <span class="stat-icon blue"><i class="bi bi-people-fill"></i></span>
      <div><div class="stat-num"><?php echo e($users); ?></div><div class="stat-label">Users</div></div>
    </a>
  </div>
</div>

<div class="d-flex flex-wrap gap-2 mb-4">
  <a href="<?php echo e(route('categories.index')); ?>" class="mini-stat"><i class="bi bi-folder2-open"></i> Categories <b><?php echo e($categories); ?></b></a>
  <a href="<?php echo e(route('tags.index')); ?>" class="mini-stat"><i class="bi bi-tags"></i> Tags <b><?php echo e($tags); ?></b></a>
  <a href="<?php echo e(route('posts.trash')); ?>" class="mini-stat"><i class="bi bi-trash3"></i> Trash <b><?php echo e($trashed); ?></b></a>
  <a href="<?php echo e(route('comments.index')); ?>" class="mini-stat"><i class="bi bi-chat-dots"></i> Pending comments <b><?php echo e($commentsPending); ?></b></a>
</div>

<div class="card shadow-sm">
  <div class="queue-head">
    <h5>⏳ Waiting for approval</h5>
    <a href="<?php echo e(route('posts.index', ['status' => 'pending'])); ?>" class="small fw-semibold">View all →</a>
  </div>

  <?php $__empty_1 = true; $__currentLoopData = $pendingPosts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <div class="queue-item">
      <span class="avatar-sm"><?php echo e(mb_strtoupper(mb_substr($post->user->name, 0, 1))); ?></span>
      <div>
        <a href="<?php echo e(route('posts.edit', $post)); ?>" class="q-title"><?php echo e($post->title); ?></a>
        <div class="q-sub"><?php echo e($post->user->name); ?> · <?php echo e($post->category->name); ?> · <?php echo e($post->created_at->diffForHumans()); ?></div>
      </div>
      <div class="q-actions">
        <form method="POST" action="<?php echo e(route('posts.approve', $post)); ?>" class="d-inline">
          <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>
          <button class="btn btn-sm btn-success"><i class="bi bi-check-lg"></i> Approve</button>
        </form>
        <form method="POST" action="<?php echo e(route('posts.reject', $post)); ?>" class="d-inline">
          <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>
          <button class="btn btn-sm btn-outline-danger"><i class="bi bi-x-lg"></i> Reject</button>
        </form>
      </div>
    </div>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    <div class="queue-empty">
      <i class="bi bi-emoji-smile"></i>
      No posts to approve.
    </div>
  <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\blog-app\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>