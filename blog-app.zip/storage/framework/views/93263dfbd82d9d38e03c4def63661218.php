<?php
  $selectedTags = old('tags', isset($post) ? $post->tags->pluck('id')->toArray() : []);
?>

<div class="mb-3">
  <label class="form-label">Title</label>
  <input type="text" name="title" class="form-control <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
         value="<?php echo e(old('title', $post->title ?? '')); ?>">
  <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="invalid-feedback"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>

<div class="mb-3">
  <label class="form-label">Category</label>
  <select name="category_id" class="form-select <?php $__errorArgs = ['category_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
    <option value="">-- Select --</option>
    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <option value="<?php echo e($category->id); ?>"
        <?php if(old('category_id', $post->category_id ?? '') == $category->id): echo 'selected'; endif; ?>>
        <?php echo e($category->name); ?>

      </option>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </select>
  <?php $__errorArgs = ['category_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="invalid-feedback"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>

<div class="mb-3">
  <label class="form-label d-block">Tags</label>
  <?php $__empty_1 = true; $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <div class="form-check form-check-inline">
      <input class="form-check-input" type="checkbox" name="tags[]" id="tag<?php echo e($tag->id); ?>"
             value="<?php echo e($tag->id); ?>" <?php if(in_array($tag->id, $selectedTags)): echo 'checked'; endif; ?>>
      <label class="form-check-label" for="tag<?php echo e($tag->id); ?>"><?php echo e($tag->name); ?></label>
    </div>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    <span class="text-muted">No Tags  (next step).</span>
  <?php endif; ?>
</div>

<?php $currentImage = isset($post) && $post->featured ? asset('storage/' . $post->featured) : null; ?>

<div class="mb-3">
  <label class="form-label">Featured Image</label>

  <label for="featuredInput" class="dropzone <?php $__errorArgs = ['featured'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="dropzone">
    <img id="featuredPreview" src="<?php echo e($currentImage); ?>" alt="" class="<?php echo e($currentImage ? '' : 'd-none'); ?>">
    <div class="dz-empty <?php echo e($currentImage ? 'd-none' : ''); ?>" id="dzEmpty">
      <i class="bi bi-cloud-arrow-up-fill"></i>
      <strong>select image</strong>
      <span>Click and this  drag &amp; drop  · JPG / PNG / WebP · 2MB less</span>
    </div>
    <div class="dz-overlay"><span><i class="bi bi-camera-fill me-1"></i> Change image</span></div>
  </label>

  <input type="file" name="featured" id="featuredInput" accept="image/*" hidden>

  <div class="d-flex justify-content-between align-items-center gap-2 mt-2">
    <small id="featuredInfo" class="text-muted"><?php echo e($currentImage ? 'now image. select new image and change.' : ''); ?></small>
    <button type="button" id="featuredClear" class="btn btn-sm btn-outline-danger d-none">
      <i class="bi bi-x-lg"></i> Remove new image
    </button>
  </div>

  <?php $__errorArgs = ['featured'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="invalid-feedback d-block"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>

<?php
  $initial = \App\Support\HtmlSanitizer::clean(old('content', isset($post) ? $post->body_html : ''));
?>

<div class="mb-3">
  <label class="form-label">Content</label>
  <div class="editor-wrap <?php $__errorArgs = ['content'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
    <div id="editor"><?php echo $initial; ?></div>
  </div>
  <input type="hidden" name="content" id="contentInput">
  <?php $__errorArgs = ['content'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="invalid-feedback d-block"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>

<?php $__env->startPush('styles'); ?>
<link href="https://cdn.jsdelivr.net/npm/quill@1.3.7/dist/quill.snow.css" rel="stylesheet">
<?php $__env->stopPush(); ?>


<?php $__env->startPush('scripts'); ?>
<script>
(function () {
  const input = document.getElementById('featuredInput');
  const zone  = document.getElementById('dropzone');
  const img   = document.getElementById('featuredPreview');
  const empty = document.getElementById('dzEmpty');
  const info  = document.getElementById('featuredInfo');
  const clear = document.getElementById('featuredClear');

  const original = img.getAttribute('src') || '';
  const MAX = 2 * 1024 * 1024;
  let previewUrl = null;

  function setInfo(text, cls) {
    info.className = 'small ' + (cls || 'text-muted');
    info.textContent = text;
  }

  
  function showOriginal() {
    if (previewUrl) { URL.revokeObjectURL(previewUrl); previewUrl = null; }
    if (original) {
      img.src = original;
      img.classList.remove('d-none');
      empty.classList.add('d-none');
      setInfo('now image.');
    } else {
      img.removeAttribute('src');
      img.classList.add('d-none');
      empty.classList.remove('d-none');
      setInfo('');
    }
    clear.classList.add('d-none');
  }

  function handle(file) {
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      input.value = '';
      showOriginal();
      setInfo('select only image file.', 'text-danger');
      return;
    }
    if (file.size > MAX) {
      input.value = '';
      showOriginal();
      setInfo('The image is larger than 2MB (' + (file.size / 1048576).toFixed(1) + ' MB). please select a smaller one.', 'text-danger');
      return;
    }

    if (previewUrl) URL.revokeObjectURL(previewUrl);
    previewUrl = URL.createObjectURL(file);
    img.src = previewUrl;
    img.classList.remove('d-none');
    empty.classList.add('d-none');
    clear.classList.remove('d-none');
    setInfo(file.name + ' · ' + Math.round(file.size / 1024) + ' KB · It will uploaded until you press save', 'text-success');
  }

  input.addEventListener('change', () => handle(input.files[0]));
  clear.addEventListener('click', () => { input.value = ''; showOriginal(); });


  ['dragenter', 'dragover'].forEach(ev => zone.addEventListener(ev, e => {
    e.preventDefault();
    zone.classList.add('drag');
  }));
  ['dragleave', 'drop'].forEach(ev => zone.addEventListener(ev, e => {
    e.preventDefault();
    zone.classList.remove('drag');
  }));
  zone.addEventListener('drop', e => {
    const file = e.dataTransfer.files[0];
    if (!file) return;
    const dt = new DataTransfer();
    dt.items.add(file);
    input.files = dt.files;
    handle(file);
  });


  const form = input.closest('form');
  const saveBtn = form.querySelector('button.btn-success');
  const saveHtml = saveBtn ? saveBtn.innerHTML : '';
  form.addEventListener('submit', () => {
    if (!saveBtn) return;
    saveBtn.disabled = true;
    saveBtn.innerHTML = '<span class="spinner-border spinner-border-sm me-2"></span>Saving...';
  });
  window.addEventListener('pageshow', e => {
    if (e.persisted && saveBtn) { saveBtn.disabled = false; saveBtn.innerHTML = saveHtml; }
  });
})();
</script>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
<script src="https://cdn.jsdelivr.net/npm/quill@1.3.7/dist/quill.min.js"></script>
<script>
  const quill = new Quill('#editor', {
    theme: 'snow',
    placeholder: 'This write your story...',
    modules: {
      toolbar: [
        [{ header: [2, 3, false] }],
        ['bold', 'italic', 'underline', 'strike'],
        [{ color: [] }, { background: [] }],
        [{ list: 'ordered' }, { list: 'bullet' }],
        [{ align: [] }],
        ['link', 'blockquote'],
        ['clean']
      ]
    }
  });

  const input = document.getElementById('contentInput');
  input.closest('form').addEventListener('submit', function () {
    input.value = quill.getText().trim().length === 0 ? '' : quill.root.innerHTML;
  });
</script>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
(function () {
  const $ = id => document.getElementById(id);
  const mt = $('metaTitle'), md = $('metaDesc');
  const titleInput = document.querySelector('input[name="title"]');


  function count(el, out, good) {
    const n = el.value.length;
    out.textContent = n + '/' + el.maxLength;
    out.className = n === 0 ? 'text-muted' : (n <= good ? 'count-ok' : 'count-warn');
  }


  function render() {
    $('serpTitle').textContent = mt.value.trim() || (titleInput ? titleInput.value.trim() : '') || 'Post title appears here';
    $('serpDesc').textContent = md.value.trim() || 'If empty meta description,it will be automatically created from the content.';
    count(mt, $('mtCount'), 60);
    count(md, $('mdCount'), 155);
  }

  [mt, md, titleInput].forEach(el => el && el.addEventListener('input', render));
  render();


  $('metaImageInput').addEventListener('change', function () {
    const f = this.files[0], img = $('metaImagePreview');
    if (!f) return;
    if (f.size > 2 * 1024 * 1024) {
      alert('The image is larger thana 2MB.');
      this.value = '';
      return;
    }
    img.src = URL.createObjectURL(f);
    img.classList.remove('d-none');
  });
})();
</script>
<?php $__env->stopPush(); ?>


<?php
  $manual = isset($post) ? ($post->meta_manual ?? []) : [];
  $isManual = fn ($f) => in_array($f, $manual, true);
  $metaImageUrl = isset($post) && $post->meta_image ? asset('storage/' . $post->meta_image) : null;


  $autoTitle = isset($post) && ! $isManual('meta_title') ? $post->meta_title : '';
  $autoDesc  = isset($post) && ! $isManual('meta_description') ? $post->meta_description : '';
  $autoKeys  = isset($post) && ! $isManual('meta_keywords') ? $post->meta_keywords : '';

  $seoOpen = $errors->hasAny(['meta_title', 'meta_description', 'meta_keywords', 'meta_image']) || count($manual) > 0;
?>

<details class="seo-box mb-4" <?php if($seoOpen): ?> open <?php endif; ?>>
  <summary>
    <i class="bi bi-magic me-2"></i> SEO &amp; social sharing
    <span class="auto-badge ms-2">Optional: leave empty to auto-generate</span>
  </summary>

  <div class="seo-body">
    <p class="text-muted small">
      You can type your own meta details for this post. Any field you leave <strong>empty</strong>
      is generated automatically from the title, content, tags and featured image.
    </p>

    <div class="serp mb-3" id="serp" data-site="<?php echo e(config('seo.site_name')); ?>">
      <div class="serp-url"><?php echo e(parse_url(config('app.url'), PHP_URL_HOST) ?: 'yoursite.com'); ?> &rsaquo; post</div>
      <div class="serp-title" id="serpTitle"></div>
      <div class="serp-desc" id="serpDesc"></div>
    </div>

    <div class="mb-3">
      <label class="form-label d-flex justify-content-between" for="metaTitle">
        <span>Meta title</span><small id="mtCount" class="text-muted"></small>
      </label>
      <input type="text" id="metaTitle" name="meta_title" maxlength="70"
             class="form-control <?php $__errorArgs = ['meta_title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
             value="<?php echo e(old('meta_title', $isManual('meta_title') ? $post->meta_title : '')); ?>"
             placeholder="<?php echo e($autoTitle ?: 'Empty = auto from the post title'); ?>">
      <?php $__errorArgs = ['meta_title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    <div class="mb-3">
      <label class="form-label d-flex justify-content-between" for="metaDesc">
        <span>Meta description</span><small id="mdCount" class="text-muted"></small>
      </label>
      <textarea id="metaDesc" name="meta_description" rows="3" maxlength="160"
                class="form-control <?php $__errorArgs = ['meta_description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                placeholder="<?php echo e($autoDesc ?: 'Empty = auto from the post content'); ?>"><?php echo e(old('meta_description', $isManual('meta_description') ? $post->meta_description : '')); ?></textarea>
      <?php $__errorArgs = ['meta_description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    <div class="mb-3">
      <label class="form-label" for="metaKeywords">Meta keywords <small class="text-muted">(comma separated)</small></label>
      <input type="text" id="metaKeywords" name="meta_keywords" maxlength="255"
             class="form-control <?php $__errorArgs = ['meta_keywords'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
             value="<?php echo e(old('meta_keywords', $isManual('meta_keywords') ? $post->meta_keywords : '')); ?>"
             placeholder="<?php echo e($autoKeys ?: 'Empty = auto from tags, category and content'); ?>">
      <?php $__errorArgs = ['meta_keywords'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    <div class="mb-1">
      <label class="form-label" for="metaImageInput">Share image <small class="text-muted">(max 2MB, 1200x630 is best)</small></label>
      <input type="file" id="metaImageInput" name="meta_image" accept="image/*"
             class="form-control <?php $__errorArgs = ['meta_image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
      <?php $__errorArgs = ['meta_image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

      <img id="metaImagePreview" src="<?php echo e($metaImageUrl); ?>" alt=""
           class="meta-preview mt-2 <?php echo e($metaImageUrl ? '' : 'd-none'); ?>" style="max-width:260px;border-radius:.6rem;">

      <?php if($isManual('meta_image')): ?>
        <div class="form-check mt-2">
          <input class="form-check-input" type="checkbox" name="remove_meta_image" value="1" id="removeMetaImage">
          <label class="form-check-label" for="removeMetaImage">Remove my custom image (use featured image instead)</label>
        </div>
      <?php else: ?>
        <div class="form-text">If you don't upload one, it is generated from the featured image.</div>
      <?php endif; ?>
    </div>
  </div>
</details>

<div>
  <button class="btn btn-success"><?php echo e($button); ?></button>
  <a href="<?php echo e(route('posts.index')); ?>" class="btn btn-secondary">Cancel</a>
</div><?php /**PATH C:\xampp\htdocs\laravel\blog-app\resources\views/admin/posts/_form.blade.php ENDPATH**/ ?>