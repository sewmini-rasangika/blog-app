
<?php $__env->startSection('title', 'Activity Log'); ?>

<?php $__env->startSection('content'); ?>
<?php
  $color = ['auth' => 'secondary', 'post' => 'primary', 'comment' => 'info', 'user' => 'warning',
            'role' => 'danger', 'category' => 'success', 'tag' => 'success', 'settings' => 'dark'];
?>

<h3 class="mb-3">Activity Log</h3>

<form method="GET" class="row g-2 mb-3">
  <div class="col-md-3">
    <input type="text" name="q" value="<?php echo e(request('q')); ?>" class="form-control" placeholder="Search...">
  </div>
  <div class="col-md-2">
    <select name="user" class="form-select">
      <option value="">All users</option>
      <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($u->id); ?>" <?php if(request('user') == $u->id): echo 'selected'; endif; ?>><?php echo e($u->name); ?></option>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
  </div>
  <div class="col-md-2">
    <select name="group" class="form-select">
      <option value="">All types</option>
      <?php $__currentLoopData = $groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $g): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($g); ?>" <?php if(request('group') === $g): echo 'selected'; endif; ?>><?php echo e(ucfirst($g)); ?></option>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
  </div>
  <div class="col-md-2"><input type="date" name="from" value="<?php echo e(request('from')); ?>" class="form-control"></div>
  <div class="col-md-2"><input type="date" name="to" value="<?php echo e(request('to')); ?>" class="form-control"></div>
  <div class="col-md-1 d-grid"><button class="btn btn-dark">Go</button></div>
</form>

<div class="card shadow-sm">
  <div class="table-responsive">
    <table class="table table-hover mb-0 align-middle">
      <thead>
        <tr><th>When</th><th>User</th><th>Action</th><th>Details</th><th>IP</th></tr>
      </thead>
      <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $logs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
          <?php $group = \Illuminate\Support\Str::before($log->action, '.'); ?>
          <tr>
            <td class="small text-muted text-nowrap" title="<?php echo e($log->created_at->format('Y-m-d H:i:s')); ?>">
              <?php echo e($log->created_at->format('M d, H:i')); ?><br><?php echo e($log->created_at->diffForHumans()); ?>

            </td>
            <td><?php echo e($log->user_name ?? 'Guest'); ?></td>
            <td><span class="badge bg-<?php echo e($color[$group] ?? 'secondary'); ?>"><?php echo e($log->action); ?></span></td>
            <td style="min-width:260px">
              <?php echo e($log->description); ?>

              <?php if($log->properties): ?>
                <div class="small text-muted">
                  <?php $__currentLoopData = $log->properties; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php echo e($k); ?>: <?php echo e(is_array($v) ? json_encode($v) : $v); ?><?php if(! $loop->last): ?> · <?php endif; ?>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
              <?php endif; ?>
            </td>
            <td class="small text-muted"><?php echo e($log->ip_address); ?></td>
          </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
          <tr><td colspan="5" class="text-center text-muted py-5">No activity yet</td></tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>

<div class="mt-3"><?php echo e($logs->links('pagination::bootstrap-5')); ?></div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\blog-app\resources\views/admin/activity/index.blade.php ENDPATH**/ ?>