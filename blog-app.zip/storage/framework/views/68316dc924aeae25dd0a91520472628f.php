
<?php $__env->startSection('title', 'Mail settings'); ?>

<?php $__env->startSection('content'); ?>
<div class="row justify-content-center">
  <div class="col-xl-8">

    
    <div class="card shadow-sm mb-4">
      <div class="p-3 d-flex align-items-center gap-3">
        <span class="stat-icon <?php echo e($saved['enabled'] ? 'green' : 'violet'); ?>" style="width:44px;height:44px;border-radius:.9rem;font-size:1.2rem">
          <i class="bi <?php echo e($saved['enabled'] ? 'bi-check2-circle' : 'bi-file-earmark-code'); ?>"></i>
        </span>
        <div>
          <?php if($saved['enabled']): ?>
            <strong>Custom SMTP is ON</strong>
            <div class="small text-muted">send mails<strong><?php echo e($activeHost); ?></strong> and (this page is settings).</div>
          <?php else: ?>
            <strong>use .env settings</strong>
            <div class="small text-muted">Mailer: <strong><?php echo e($activeMailer); ?></strong><?php echo e($activeHost ? ' · ' . $activeHost : ''); ?></div>
          <?php endif; ?>
        </div>
      </div>
    </div>

    <form method="POST" action="<?php echo e(route('settings.mail.update')); ?>" class="card shadow-sm" autocomplete="off">
      <?php echo csrf_field(); ?>

      <div class="settings-head">
        <span class="stat-icon blue"><i class="bi bi-envelope-at"></i></span>
        <div><h5>SMTP configuration</h5><p>The server that send emails like reset password, notifications.</p></div>
      </div>

      <div class="p-4">

       
        <div class="form-check form-switch mb-4">
          <input type="hidden" name="smtp_enabled" value="0">
          <input class="form-check-input" type="checkbox" role="switch" id="smtpEnabled" name="smtp_enabled" value="1"
                 <?php if(old('smtp_enabled', $saved['enabled'] ? '1' : '0') == '1'): echo 'checked'; endif; ?>>
          <label class="form-check-label fw-semibold" for="smtpEnabled">use this setting (override .env settings)</label>
        </div>

       
        <div class="d-flex flex-wrap align-items-center gap-2 mb-3">
          <span class="text-muted small">Quick fill:</span>
          <button type="button" class="preset-chip" data-preset="gmail">Gmail</button>
          <button type="button" class="preset-chip" data-preset="outlook">Outlook</button>
          <button type="button" class="preset-chip" data-preset="brevo">Brevo</button>
          <button type="button" class="preset-chip" data-preset="mailtrap">Mailtrap</button>
        </div>

       
        <div class="row g-3 mb-3">
          <div class="col-md-6">
            <label class="form-label">SMTP host</label>
            <input type="text" name="smtp_host" id="smtpHost" value="<?php echo e(old('smtp_host', $saved['host'])); ?>"
                   class="form-control <?php $__errorArgs = ['smtp_host'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="smtp.gmail.com" autocomplete="off">
            <?php $__errorArgs = ['smtp_host'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="invalid-feedback"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>
          <div class="col-md-3">
            <label class="form-label">Port</label>
            <input type="number" name="smtp_port" id="smtpPort" value="<?php echo e(old('smtp_port', $saved['port'])); ?>"
                   class="form-control <?php $__errorArgs = ['smtp_port'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="587">
            <?php $__errorArgs = ['smtp_port'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="invalid-feedback"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>
          <div class="col-md-3">
            <label class="form-label">Encryption</label>
            <select name="smtp_encryption" id="smtpEnc" class="form-select <?php $__errorArgs = ['smtp_encryption'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
              <?php $__currentLoopData = ['tls' => 'TLS / STARTTLS (587)', 'ssl' => 'SSL (465)', 'none' => 'None']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($k); ?>" <?php if(old('smtp_encryption', $saved['encryption']) === $k): echo 'selected'; endif; ?>><?php echo e($label); ?></option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
          </div>
        </div>

       
        <div class="row g-3 mb-3">
          <div class="col-md-6">
            <label class="form-label">Username</label>
            <input type="text" name="smtp_username" value="<?php echo e(old('smtp_username', $saved['username'])); ?>"
                   class="form-control" placeholder="you@gmail.com" autocomplete="off">
          </div>
          <div class="col-md-6">
            <label class="form-label">Password</label>
            <div class="input-group">
              <input type="password" name="smtp_password" id="smtpPass" autocomplete="new-password"
                     class="form-control" placeholder="<?php echo e($hasPassword ? '•••••••• (saved. empty = no change)' : 'App password / SMTP password'); ?>">
              <button type="button" class="btn btn-eye" data-toggle-pass="smtpPass"><i class="bi bi-eye"></i></button>
            </div>
            <?php if($hasPassword): ?>
              <div class="form-check mt-2">
                <input class="form-check-input" type="checkbox" name="clear_password" value="1" id="clearPass">
                <label class="form-check-label small" for="clearPass">delete the saved password.</label>
              </div>
            <?php endif; ?>
          </div>
        </div>

        
        <div class="row g-3 mb-4">
          <div class="col-md-6">
            <label class="form-label">From address</label>
            <input type="email" name="smtp_from_address" value="<?php echo e(old('smtp_from_address', $saved['from_address'])); ?>"
                   class="form-control <?php $__errorArgs = ['smtp_from_address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="noreply@yourdomain.com">
            <?php $__errorArgs = ['smtp_from_address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="invalid-feedback"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>
          <div class="col-md-6">
            <label class="form-label">From name</label>
            <input type="text" name="smtp_from_name" value="<?php echo e(old('smtp_from_name', $saved['from_name'])); ?>"
                   class="form-control" placeholder="<?php echo e(config('app.name')); ?>">
          </div>
        </div>

        <button type="submit" class="btn btn-primary px-4"><i class="bi bi-check2-circle me-1"></i> Save settings</button>

        <hr class="my-4">

      
        <h6 class="mb-1"><i class="bi bi-send me-1"></i> Send a test email</h6>
        <p class="text-muted small">It sends a test using the values currently in the form(even if not saved yet).</p>
        <div class="row g-2">
          <div class="col-md-8">
            <input type="email" name="test_to" value="<?php echo e(old('test_to', auth()->user()->email)); ?>"
                   class="form-control <?php $__errorArgs = ['test_to'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="The address where the test mail should be sent">
            <?php $__errorArgs = ['test_to'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="invalid-feedback"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>
          <div class="col-md-4">
            <button type="submit" formaction="<?php echo e(route('settings.mail.test')); ?>" class="btn btn-outline-primary w-100">
              <i class="bi bi-send me-1"></i> Send test
            </button>
          </div>
        </div>

      </div>
    </form>

  </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>

  document.querySelectorAll('[data-toggle-pass]').forEach(function (btn) {
    btn.addEventListener('click', function () {
      const input = document.getElementById(btn.dataset.togglePass);
      const show = input.type === 'password';
      input.type = show ? 'text' : 'password';
      btn.innerHTML = show ? '<i class="bi bi-eye-slash"></i>' : '<i class="bi bi-eye"></i>';
    });
  });


  const presets = {
    gmail:    ['smtp.gmail.com', 587, 'tls'],
    outlook:  ['smtp.office365.com', 587, 'tls'],
    brevo:    ['smtp-relay.brevo.com', 587, 'tls'],
    mailtrap: ['sandbox.smtp.mailtrap.io', 2525, 'tls'],
  };
  document.querySelectorAll('[data-preset]').forEach(function (btn) {
    btn.addEventListener('click', function () {
      const p = presets[btn.dataset.preset];
      document.getElementById('smtpHost').value = p[0];
      document.getElementById('smtpPort').value = p[1];
      document.getElementById('smtpEnc').value = p[2];
    });
  });


  document.getElementById('smtpEnc').addEventListener('change', function () {
    const port = document.getElementById('smtpPort');
    if (this.value === 'ssl' && ['587', '2525', ''].includes(port.value)) port.value = 465;
    if (this.value === 'tls' && port.value === '465') port.value = 587;
  });
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\blog-app\resources\views/admin/settings/mail.blade.php ENDPATH**/ ?>