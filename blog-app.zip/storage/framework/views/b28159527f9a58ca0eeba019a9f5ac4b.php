<section id="comments" class="comments">
  <h2 class="section-title">Comments <span class="comment-count"><?php echo e($commentCount); ?></span></h2>

  <?php if(session('comment_status')): ?>
    <div class="alert alert-success"><i class="bi bi-check-circle-fill me-1"></i> <?php echo e(session('comment_status')); ?></div>
  <?php endif; ?>

  <?php if($post->status === 'approved'): ?>
    <?php echo $__env->make('frontend._comment_form', ['post' => $post, 'parentId' => null], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
  <?php else: ?>
    <div class="alert alert-warning">you can put comment approved post.</div>
  <?php endif; ?>

  <div class="comment-list mt-4">
    <?php $__empty_1 = true; $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
      <?php echo $__env->make('frontend._comment', ['comment' => $comment, 'post' => $post, 'isReply' => false], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
      <div class="empty-state py-4">
        <i class="bi bi-chat-heart"></i>
        <h5>no comments</h5>
        <p class="text-muted mb-0">may the first comment be from you!</p>
      </div>
    <?php endif; ?>
  </div>

  <div class="mt-3 d-flex justify-content-center">
    <?php echo e($comments->links('pagination::bootstrap-5')); ?>

  </div>
</section>

<?php $__env->startPush('scripts'); ?>
<script>
  
  document.querySelectorAll('[data-reply]').forEach(function (btn) {
    btn.addEventListener('click', function () {
      const box = document.getElementById('reply-box-' + btn.dataset.reply);
      box.classList.toggle('d-none');
      if (!box.classList.contains('d-none')) box.querySelector('textarea').focus();
    });
  });

  if (document.querySelector('#comments .is-invalid, #comments .alert')) {
    document.getElementById('comments').scrollIntoView({ behavior: 'smooth' });
  }
</script>
<?php $__env->stopPush(); ?><?php /**PATH C:\xampp\htdocs\laravel\blog-app\resources\views/frontend/_comments.blade.php ENDPATH**/ ?>