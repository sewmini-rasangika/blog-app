<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use App\Support\Activity;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    

{
    Schema::table('roles', function (Blueprint $table) {
        $table->json('permissions')->nullable()->after('description');
    });

       
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('roles', function (Blueprint $table) {
            //
        });
    }
};
