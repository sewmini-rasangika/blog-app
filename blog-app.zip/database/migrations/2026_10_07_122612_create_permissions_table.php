<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use App\Support\Activity;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('permissions', function (Blueprint $table) {
            $table->id();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('permissions');
    }
};

Schema::create('permissions', function (Blueprint $table) {
    $table->id();
    $table->string('name'); // create-own-post
    $table->string('display_name'); // Create & edit own posts
    $table->string('description')->nullable();
    $table->string('group'); // Posts, Comments, Admin panel
    $table->timestamps();
});
