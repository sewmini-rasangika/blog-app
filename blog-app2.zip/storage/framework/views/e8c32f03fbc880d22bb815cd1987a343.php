
<?php $__env->startSection('title', 'API Tokens'); ?>

<?php $__env->startSection('content'); ?>
<div class="row justify-content-center">
  <div class="col-xl-9">

    
    <?php if(session('new_token')): ?>
      <div class="card shadow-sm mb-4 border-success">
        <div class="p-3">
          <strong class="text-success"><i class="bi bi-check-circle-fill me-1"></i> Token created</strong>
          <div class="small text-muted mb-2">Copy it now. For security it will <strong>not be shown again</strong>.</div>
          <div class="input-group">
            <input type="text" id="newToken" class="form-control font-monospace" value="<?php echo e(session('new_token')); ?>" readonly>
            <button type="button" class="btn btn-primary" id="copyToken"><i class="bi bi-clipboard"></i> Copy</button>
          </div>
        </div>
      </div>
    <?php endif; ?>

    
    <form method="POST" action="<?php echo e(route('tokens.store')); ?>" class="card shadow-sm mb-4">
      <?php echo csrf_field(); ?>
      <div class="settings-head">
        <span class="stat-icon blue"><i class="bi bi-key"></i></span>
        <div><h5>Create API token</h5><p>Use it with <code>Authorization: Bearer &lt;token&gt;</code> to call the API.</p></div>
      </div>
      <div class="p-4 d-flex gap-2">
        <div class="p-4">
        <div class="row g-2">
            <div class="col-md-6">
            <input type="text" name="name" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                    placeholder="Token name (e.g. Postman, Mobile app)" value="<?php echo e(old('name')); ?>" required maxlength="60">
            </div>
            <div class="col-md-4">
            <input type="date" name="expires_at" class="form-control <?php $__errorArgs = ['expires_at'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                    value="<?php echo e(old('expires_at')); ?>" min="<?php echo e(now()->addDay()->toDateString()); ?>"
                    title="Expiry date (leave empty = never expires)">
            </div>
            <div class="col-md-2 d-grid">
            <button class="btn btn-primary">Generate</button>
            </div>
        </div>
        <div class="form-text">Expiry date optional. Empty nam token eka <strong>never expires</strong>.</div>
        </div>
        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>       <div class="px-4 pb-3 text-danger small"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        <?php $__errorArgs = ['expires_at'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="px-4 pb-3 text-danger small"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
      </div>
      <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="px-4 pb-3 text-danger small"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </form>

    
    <div class="card shadow-sm">
    <table class="table table-hover mb-0 align-middle">
        <thead class="table-light">
        <tr>
            <th>Name</th>
            <th>Created</th>
            <th>Last used</th>
            <th>Expires</th>
            <th class="text-end">Actions</th>
        </tr>
        </thead>
        <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $tokens; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
            <td><i class="bi bi-key me-1 text-muted"></i><?php echo e($t->name); ?></td>
            <td class="text-muted small"><?php echo e($t->created_at->diffForHumans()); ?></td>
            <td class="text-muted small"><?php echo e($t->last_used_at?->diffForHumans() ?? 'Never'); ?></td>
            <td class="small">
                <?php if(! $t->expires_at): ?>
                <span class="badge bg-secondary-subtle text-secondary">Never</span>
                <?php elseif($t->expires_at->isPast()): ?>
                <span class="badge bg-danger-subtle text-danger">Expired</span>
                <?php else: ?>
                <span class="text-muted" title="<?php echo e($t->expires_at->toDayDateTimeString()); ?>"><?php echo e($t->expires_at->diffForHumans()); ?></span>
                <?php endif; ?>
            </td>
            <td class="text-end">
                <button type="button" class="btn btn-sm btn-danger"
                data-bs-toggle="modal" data-bs-target="#deleteModal"
                data-action="<?php echo e(route('tokens.destroy', $t->id)); ?>"
                data-name="<?php echo e($t->name); ?>">Revoke</button>
            </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr><td colspan="5" class="text-center text-muted py-4">No API tokens yet.</td></tr>
        <?php endif; ?>
        </tbody>
    </table>
    </div>

    <p class="small text-muted mt-3 mb-0">API base URL: <code><?php echo e(url('/api/v1')); ?></code></p>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
  document.getElementById('copyToken')?.addEventListener('click', function () {
    const input = document.getElementById('newToken');
    navigator.clipboard.writeText(input.value).then(() => {
      this.innerHTML = '<i class="bi bi-check2"></i> Copied';
    });
  });
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\blog-app\resources\views/admin/tokens/index.blade.php ENDPATH**/ ?>