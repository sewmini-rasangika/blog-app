<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title><?php echo $__env->yieldContent('title', 'Dashboard'); ?> · <?php echo e(config('app.name', 'My Blog')); ?></title>

  <script>
    (function () {
      var t = null;
      try { t = localStorage.getItem('theme'); } catch (e) {}
      document.documentElement.setAttribute('data-bs-theme', t === 'dark' ? 'dark' : 'light');
      document.documentElement.classList.add('js');
    })();
  </script>

  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600&family=Poppins:wght@500;600;700&display=swap" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
  <link href="<?php echo e(asset('css/blog.css')); ?>?v=<?php echo e(filemtime(public_path('css/blog.css'))); ?>" rel="stylesheet">
  <link href="<?php echo e(asset('css/admin.css')); ?>?v=<?php echo e(filemtime(public_path('css/admin.css'))); ?>" rel="stylesheet">
  <?php echo $__env->yieldPushContent('styles'); ?>
  <link href="<?php echo e(asset('css/dark.css')); ?>?v=<?php echo e(filemtime(public_path('css/dark.css'))); ?>" rel="stylesheet">
</head>
<body class="admin-body">
<?php echo $__env->make('partials.loader', ['nav' => false], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<div class="top-loader" id="topLoader"></div>

<?php
  $me = auth()->user();
  $is = fn (...$r) => request()->routeIs(...$r) ? 'active' : '';
  $pendingCount = $pendingCount ?? 0;
  $pendingComments = $pendingComments ?? 0;
  $meAvatar = $meAvatar ?? null;
?>

<div class="sidebar-backdrop" id="sbBackdrop"></div>


<aside class="sidebar" id="sidebar">
  <a class="brand" href="<?php echo e(route('home')); ?>">
    <span class="brand-mark"><i class="bi bi-pen-fill"></i></span>
    <span>My<span class="brand-accent">Blog</span></span>
  </a>


  <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('posts.create')): ?>
    <a href="<?php echo e(route('posts.create')); ?>" class="side-cta"><i class="bi bi-plus-lg"></i> New Post</a>
  <?php endif; ?>

  <nav>
    <div class="side-label">Menu</div>
    <a class="side-link <?php echo e($is('dashboard')); ?>" href="<?php echo e(route('dashboard')); ?>">
      <i class="bi bi-speedometer2"></i> Dashboard
    </a>
    <a class="side-link <?php echo e($is('posts.index', 'posts.create', 'posts.edit')); ?>" href="<?php echo e(route('posts.index')); ?>">
      <i class="bi bi-file-earmark-text"></i> <?php echo e($me->can('posts.view_all') ? 'Posts' : 'My Posts'); ?>

      <?php if($pendingCount > 0): ?>
        <span class="side-badge"><?php echo e($pendingCount); ?></span>
      <?php endif; ?>
    </a>

   
    <?php if($me->isAdmin() || $me->canAny(['categories.manage', 'tags.manage', 'users.manage', 'comments.moderate', 'posts.trash', 'settings.manage'])): ?>
      <div class="side-label">Manage</div>
    <?php endif; ?>

    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('categories.manage')): ?>
      <a class="side-link <?php echo e($is('categories.*')); ?>" href="<?php echo e(route('categories.index')); ?>"><i class="bi bi-folder2-open"></i> Categories</a>
    <?php endif; ?>

    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('tags.manage')): ?>
      <a class="side-link <?php echo e($is('tags.*')); ?>" href="<?php echo e(route('tags.index')); ?>"><i class="bi bi-tags"></i> Tags</a>
    <?php endif; ?>

    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('comments.moderate')): ?>
      <a class="side-link <?php echo e($is('comments.*')); ?>" href="<?php echo e(route('comments.index')); ?>">
        <i class="bi bi-chat-dots"></i> Comments
        <?php if($pendingComments > 0): ?>
          <span class="side-badge"><?php echo e($pendingComments); ?></span>
        <?php endif; ?>
      </a>
    <?php endif; ?>

    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('users.manage')): ?>
      <a class="side-link <?php echo e($is('users.*')); ?>" href="<?php echo e(route('users.index')); ?>"><i class="bi bi-people"></i> Users</a>
    <?php endif; ?>

   
    <?php if($me->isAdmin()): ?>
      <a class="side-link <?php echo e($is('roles.*')); ?>" href="<?php echo e(route('roles.index')); ?>"><i class="bi bi-shield-lock"></i> Roles &amp; Permissions</a>
    <?php endif; ?>

    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('posts.trash')): ?>
      <a class="side-link <?php echo e($is('posts.trash')); ?>" href="<?php echo e(route('posts.trash')); ?>"><i class="bi bi-trash3"></i> Trash</a>
    <?php endif; ?>

    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('activity.view')): ?>
  <a class="side-link <?php echo e($is('activity.*')); ?>" href="<?php echo e(route('activity.index')); ?>"><i class="bi bi-clock-history"></i> Activity Log</a>
<?php endif; ?>

    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('settings.manage')): ?>
      <a class="side-link <?php echo e($is('settings.*')); ?>" href="<?php echo e(route('settings.mail')); ?>"><i class="bi bi-envelope"></i> Mail settings</a>
    <?php endif; ?>

    <div class="side-label">Account</div>
    <a class="side-link <?php echo e($is('myprofile.*')); ?>" href="<?php echo e(route('myprofile.edit')); ?>"><i class="bi bi-person-circle"></i> My Profile</a>
    <a class="side-link <?php echo e($is('profile.*')); ?>" href="<?php echo e(route('profile.edit')); ?>"><i class="bi bi-gear"></i> Account settings</a>
    <a class="side-link" href="<?php echo e(route('home')); ?>" target="_blank"><i class="bi bi-box-arrow-up-right"></i> View site</a>
    <a class="side-link <?php echo e($is('tokens.*')); ?>" href="<?php echo e(route('tokens.index')); ?>"><i class="bi bi-key"></i> API Tokens</a>
  </nav>

  <div class="side-user">
    <span class="avatar-md">
      <?php if($meAvatar): ?>
        <img src="<?php echo e(asset('storage/' . $meAvatar)); ?>" alt="">
      <?php else: ?>
        <?php echo e(mb_strtoupper(mb_substr($me->name, 0, 1))); ?>

      <?php endif; ?>
    </span>
    <div>
      <strong><?php echo e(\Illuminate\Support\Str::limit($me->name, 18)); ?></strong>
      <small><?php echo e($me->isAdmin() ? 'Administrator' : ucfirst($me->role)); ?></small>
    </div>
  </div>
</aside>


<div class="admin-main">

  <header class="topbar">
    <div class="d-flex align-items-center gap-3">
      <button type="button" class="icon-btn menu-btn" id="menuBtn" aria-label="Menu"><i class="bi bi-list fs-5"></i></button>
      <h1 class="topbar-title"><?php echo $__env->yieldContent('title', 'Dashboard'); ?></h1>
    </div>

    <div class="d-flex align-items-center gap-2">
      <button type="button" class="icon-btn" data-theme-toggle aria-label="Dark / Light" title="Dark / Light">
        <i class="bi bi-moon-stars-fill icon-moon"></i><i class="bi bi-sun-fill icon-sun"></i>
      </button>
      <a href="<?php echo e(route('home')); ?>" target="_blank" class="icon-btn" title="View site"><i class="bi bi-globe2"></i></a>

              <?php
        $unread = $me->unreadNotifications()->count();
        $latest = $me->notifications()->latest()->take(5)->get();
      ?>
      <div class="dropdown">
        <button type="button" class="icon-btn position-relative" data-bs-toggle="dropdown" aria-expanded="false" title="Notifications">
          <i class="bi bi-bell-fill"></i>
          <?php if($unread): ?>
            <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger"><?php echo e($unread > 9 ? '9+' : $unread); ?></span>
          <?php endif; ?>
        </button>

        <div class="dropdown-menu dropdown-menu-end p-0" style="min-width: 320px;">
          <div class="d-flex justify-content-between align-items-center px-3 py-2 border-bottom">
            <strong>Notifications</strong>
            <?php if($unread): ?>
              <form method="POST" action="<?php echo e(route('notifications.readAll')); ?>">
                <?php echo csrf_field(); ?>
                <button class="btn btn-link btn-sm p-0">Mark all as read</button>
              </form>
            <?php endif; ?>
          </div>

          <?php $__empty_1 = true; $__currentLoopData = $latest; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $n): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <a href="<?php echo e(route('notifications.read', $n->id)); ?>"
               class="dropdown-item d-flex gap-2 py-2 <?php echo e($n->read_at ? '' : 'fw-semibold'); ?>"
               style="white-space: normal;">
              <i class="bi bi-check-circle-fill text-success mt-1"></i>
              <span>
                <?php echo e($n->data['message'] ?? 'Notification'); ?>

                <small class="d-block text-muted"><?php echo e($n->created_at->diffForHumans()); ?></small>
              </span>
            </a>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="text-center text-muted py-4 small">No notifications yet</div>
          <?php endif; ?>
        </div>
      </div>
      <div class="dropdown">
        <button class="user-chip" data-bs-toggle="dropdown" aria-expanded="false">
          <span class="avatar-md">
            <?php if($meAvatar): ?>
              <img src="<?php echo e(asset('storage/' . $meAvatar)); ?>" alt="">
            <?php else: ?>
              <?php echo e(mb_strtoupper(mb_substr($me->name, 0, 1))); ?>

            <?php endif; ?>
          </span>
          <span class="d-none d-sm-inline"><?php echo e(\Illuminate\Support\Str::limit($me->name, 16)); ?></span>
          <i class="bi bi-chevron-down small"></i>
        </button>
        <ul class="dropdown-menu dropdown-menu-end">
          <li class="px-3 py-2">
            <div class="fw-semibold"><?php echo e($me->name); ?></div>
            <div class="small text-muted"><?php echo e($me->email); ?></div>
            <span class="role-pill mt-1 d-inline-block"><?php echo e($me->isAdmin() ? 'Administrator' : ucfirst($me->role)); ?></span>
          </li>
          <li><hr class="dropdown-divider"></li>
          <li><a class="dropdown-item" href="<?php echo e(route('myprofile.edit')); ?>"><i class="bi bi-person-circle me-2"></i>My Profile</a></li>
          <li><a class="dropdown-item" href="<?php echo e(route('profile.edit')); ?>"><i class="bi bi-gear me-2"></i>Account settings</a></li>
          <li>
            <form method="POST" action="<?php echo e(route('logout')); ?>">
              <?php echo csrf_field(); ?>
              <button class="dropdown-item text-danger"><i class="bi bi-box-arrow-right me-2"></i>Logout</button>
            </form>
          </li>
        </ul>
      </div>
    </div>
  </header>

  <main class="admin-content">
    <?php echo $__env->yieldContent('content'); ?>
  </main>
</div>


<div class="toast-container position-fixed top-0 end-0 p-3" style="z-index:2000; margin-top:62px;">
  <?php
    $statusMsg = [
      'profile-updated'  => 'updated account details ✨',
      'password-updated' => 'changed password 🔒',
    ][session('status')] ?? null;
  ?>
  <?php if($statusMsg): ?>
    <div class="toast app-toast ok" role="alert" data-bs-delay="4500">
      <div class="d-flex">
        <div class="toast-body"><i class="bi bi-check-circle-fill me-2"></i><?php echo e($statusMsg); ?></div>
        <button type="button" class="btn-close btn-close-white m-auto me-3" data-bs-dismiss="toast"></button>
      </div>
    </div>
  <?php endif; ?>

  <?php if(session('success')): ?>
    <div class="toast app-toast ok" role="alert" data-bs-delay="4500">
      <div class="d-flex">
        <div class="toast-body"><i class="bi bi-check-circle-fill me-2"></i><?php echo e(session('success')); ?></div>
        <button type="button" class="btn-close btn-close-white m-auto me-3" data-bs-dismiss="toast"></button>
      </div>
    </div>
  <?php endif; ?>

  <?php if(session('error')): ?>
    <div class="toast app-toast bad" role="alert" data-bs-delay="6000">
      <div class="d-flex">
        <div class="toast-body"><i class="bi bi-exclamation-triangle-fill me-2"></i><?php echo e(session('error')); ?></div>
        <button type="button" class="btn-close btn-close-white m-auto me-3" data-bs-dismiss="toast"></button>
      </div>
    </div>
  <?php endif; ?>

  <?php if($errors->any()): ?>
    <div class="toast app-toast bad" role="alert" data-bs-delay="6000">
      <div class="d-flex">
        <div class="toast-body"><i class="bi bi-exclamation-triangle-fill me-2"></i>Form  has <?php echo e($errors->count()); ?>errors. test.</div>
        <button type="button" class="btn-close btn-close-white m-auto me-3" data-bs-dismiss="toast"></button>
      </div>
    </div>
  <?php endif; ?>
</div>

<?php if (isset($component)) { $__componentOriginalb7eac87efb73c0c2c26fe03ec80faafd = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb7eac87efb73c0c2c26fe03ec80faafd = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.delete-modal','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('delete-modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb7eac87efb73c0c2c26fe03ec80faafd)): ?>
<?php $attributes = $__attributesOriginalb7eac87efb73c0c2c26fe03ec80faafd; ?>
<?php unset($__attributesOriginalb7eac87efb73c0c2c26fe03ec80faafd); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb7eac87efb73c0c2c26fe03ec80faafd)): ?>
<?php $component = $__componentOriginalb7eac87efb73c0c2c26fe03ec80faafd; ?>
<?php unset($__componentOriginalb7eac87efb73c0c2c26fe03ec80faafd); ?>
<?php endif; ?>

<button type="button" class="to-top" id="toTop" aria-label="Back to top"><i class="bi bi-arrow-up"></i></button>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="<?php echo e(asset('js/app.js')); ?>?v=<?php echo e(filemtime(public_path('js/app.js'))); ?>"></script>
<script>
  // Mobile sidebar
  const body = document.body;
  document.getElementById('menuBtn').addEventListener('click', () => body.classList.toggle('sidebar-open'));
  document.getElementById('sbBackdrop').addEventListener('click', () => body.classList.remove('sidebar-open'));

  // Toasts
  document.querySelectorAll('.app-toast').forEach(el => bootstrap.Toast.getOrCreateInstance(el).show());
</script>
<?php echo $__env->yieldPushContent('scripts'); ?>
</body>
</html><?php /**PATH C:\xampp\htdocs\laravel\blog-app\resources\views/layouts/admin.blade.php ENDPATH**/ ?>